////////////////////////////////////////////////////////////////////////////
//
// Copyright 2014 Realm Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
////////////////////////////////////////////////////////////////////////////

#import <Realm/RLMResults.h>

#import "RLMRealm_Private.h"

@class RLMObjectSchema;

RLM_HEADER_AUDIT_BEGIN(nullability)

@interface RLMResults ()
@property (nonatomic, readonly, getter=isAttached) BOOL attached;

+ (instancetype)emptyDetachedResults;
- (RLMResults *)snapshot;

- (void)subscribeWithName:(NSString *_Nullable)name
              waitForSync:(RLMWaitForSyncMode)waitForSyncMode
               confinedTo:(RLMScheduler *)confinement
                  timeout:(NSTimeInterval)timeout
               completion:(RLMResultsCompletionBlock)completion;

@end

RLM_HEADER_AUDIT_END(nullability)
